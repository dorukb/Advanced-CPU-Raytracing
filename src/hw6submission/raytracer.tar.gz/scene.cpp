#include "scene.h"

namespace DorkTracer{
    float Scene::shadow_ray_epsilon = 0.001f;
};