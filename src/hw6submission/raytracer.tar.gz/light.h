#ifndef __DORKTRACER_LIGHT__
#define __DORKTRACER_LIGHT__


namespace DorkTracer
{
    class Light
    {
    public:
        int id;
        Light(int id)
        {
            this->id = id;
        };
    };
}
#endif