#include "shape.hpp"

using namespace DorkTracer;
